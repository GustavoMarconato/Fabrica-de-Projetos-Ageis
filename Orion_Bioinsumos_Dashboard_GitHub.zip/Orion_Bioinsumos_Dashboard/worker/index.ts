/** Cloudflare Worker entry point for the vinext-starter template. */
import { handleImageOptimization, DEFAULT_DEVICE_SIZES, DEFAULT_IMAGE_SIZES } from "vinext/server/image-optimization";
import handler from "vinext/server/app-router-entry";

interface Env {
  ASSETS: Fetcher;
  DB: D1Database;
  IMAGES: {
    input(stream: ReadableStream): {
      transform(options: Record<string, unknown>): {
        output(options: { format: string; quality: number }): Promise<{ response(): Response }>;
      };
    };
  };
}

interface ExecutionContext {
  waitUntil(promise: Promise<unknown>): void;
  passThroughOnException(): void;
}

const ORION_SHEET_CSV_URL =
  "https://docs.google.com/spreadsheets/d/e/2PACX-1vTrAmRWRlvQSllEj-89GAclvSIToZtr_CbPoNki_l0s3aSSdwrkNZyX64cLp5IiPg/pub?gid=1204955107&single=true&output=csv";

async function fetchLiveExcel(): Promise<Response> {
  const downloadUrl = new URL(ORION_SHEET_CSV_URL);
  downloadUrl.searchParams.set("_", Date.now().toString());

  const upstream = await fetch(downloadUrl.toString(), {
    redirect: "follow",
    cache: "no-store",
  });

  if (!upstream.ok) {
    return Response.json(
      { error: "Não foi possível consultar o Google Planilhas.", status: upstream.status },
      { status: 502, headers: { "Cache-Control": "no-store" } },
    );
  }

  const csv = await upstream.text();
  if (!csv.includes("Data e hora") || !csv.includes("Janela de aplicação")) {
    return Response.json(
      { error: "A aba publicada não contém as colunas esperadas." },
      { status: 502, headers: { "Cache-Control": "no-store" } },
    );
  }

  return new Response(csv, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": "inline; filename=Orion_Previsao_Horaria.csv",
      "Cache-Control": "no-store, no-cache, must-revalidate",
    },
  });
}

// Image security config. SVG sources with .svg extension auto-skip the
// optimization endpoint on the client side (served directly, no proxy).
// To route SVGs through the optimizer (with security headers), set
// dangerouslyAllowSVG: true in next.config.js and uncomment below:
// const imageConfig: ImageConfig = { dangerouslyAllowSVG: true };

const worker = {
  async fetch(request: Request, env: Env, ctx: ExecutionContext): Promise<Response> {
    const url = new URL(request.url);

    if (url.pathname === "/api/excel-live") {
      try {
        return await fetchLiveExcel();
      } catch {
        return Response.json(
          { error: "A conexão com o Google Planilhas falhou." },
          { status: 502, headers: { "Cache-Control": "no-store" } },
        );
      }
    }

    if (url.pathname === "/_vinext/image") {
      const allowedWidths = [...DEFAULT_DEVICE_SIZES, ...DEFAULT_IMAGE_SIZES];
      return handleImageOptimization(request, {
        fetchAsset: (path) => env.ASSETS.fetch(new Request(new URL(path, request.url))),
        transformImage: async (body, { width, format, quality }) => {
          const result = await env.IMAGES.input(body).transform(width > 0 ? { width } : {}).output({ format, quality });
          return result.response();
        },
      }, allowedWidths);
    }

    return handler.fetch(request, env, ctx);
  },
};

export default worker;
